import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score

data = pd.read_csv("C:\Users\mathe\Desktop\dm\Preprocessed_data\\2015-2016_merged-csv_mod.csv")
x=data.iloc[:, 3:-1]
y=data.iloc[:,1]

rf = RandomForestRegressor(n_estimators=1000)
rf.fit(x,y)
pred=rf.predict(x)

plt.scatter(y,pred)
plt.show()

print r2_score(y,pred)
